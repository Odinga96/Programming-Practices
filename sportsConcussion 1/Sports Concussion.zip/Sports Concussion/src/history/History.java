package history;

import diagnosis.Symptom;

import java.io.Serializable;
import java.util.List;

public class History implements Serializable {

    private List<Symptom>  playerSyptoms;


    public History(List<Symptom> playerSyptoms) {
        this.playerSyptoms = playerSyptoms;
    }

    public History() {
    }

    public List<Symptom> getPlayerSyptoms() {
        return playerSyptoms;
    }

    public void setPlayerSyptoms(List<Symptom> playerSyptoms) {
        this.playerSyptoms = playerSyptoms;
    }
}
