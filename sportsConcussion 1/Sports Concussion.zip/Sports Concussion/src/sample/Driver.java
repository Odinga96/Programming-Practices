package sample;

import diagnosis.Symptom;
import history.History;
import javafx.application.Application;
import javafx.event.EventType;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Driver extends Application {

    //Array to hold player previous 5 history
//    private History[]  myHistory=new History[5];

    private List<History> myHistory=new ArrayList<>();


    public static Stage mainStage=new Stage();
    public ImageView imageView;
    @Override
    public void start(Stage primaryStage) throws Exception{
        AnchorPane root =new AnchorPane();

        root.setMinSize(500,500);

        Image image=new Image("atRisk.jpeg");
        imageView=new ImageView(image);
        imageView.setX(150);
        imageView.setY(100);
        imageView.setFitHeight(250);
        imageView.setFitWidth(250);




        root.getChildren().addAll(imageView);
        mainStage.setTitle("Sports concussion risk review");
        mainStage.setScene(new Scene(root, 500, 500));
        mainStage.setOnCloseRequest(e->{
            mainStage.hide();
            openSelectedMenu(displayMenu());

        });


        System.out.println("\n\t\t\t\t\t\t\t\t\t***************************************************************\n" +
                           "\t\t\t\t\t\t\t\t\t****                                                       ****\n" +
                           "\t\t\t\t\t\t\t\t\t****     \033[4;1;96m Welcome to Sport Concussion Assessment System \033[0m   ****\n" +
                           "\t\t\t\t\t\t\t\t\t****                                                       ****\n" +
                           "\t\t\t\t\t\t\t\t\t***************************************************************");



        //Load the player history
        loadHistory();

        //display menu and also open the menu selected
        openSelectedMenu(displayMenu());



    }


    public static void main(String[] args) {
        launch(args);
    }


    private void getSymptopms(){
        //remove first symptom if history equals five

        System.out.println(myHistory.size());
        if (myHistory.size() == 5)
            myHistory.remove(0);



        try (Scanner scanner = new Scanner(new File("symptoms.txt"))) {

//            Scanner

            int s_count=1;

//            Arraylist to store the symptoms
            ArrayList<Symptom> symptoms=new ArrayList<>();

            while (scanner.hasNextLine()) {
                String symptom=scanner.nextLine();

                String formated=String.format("%"+(120-symptom.length())+"s","\u001B[1;32m(none(0),\u001B[1;35m mid(1-2), \u001B[0;34m moderate(3-4)" +
                        ",\u001B[0;37m & \u001B[0;31msevere(5-6)):\u001B[0m");

                boolean pickValue=true;
                int score = 0;

                if (s_count<23) {
                    while (pickValue) {

                        System.out.print(s_count + ":\tplease enter your " + symptom + "\u001B[0m" + " score " + formated);
                        score = new Scanner(System.in).nextInt();
                        System.out.println();

                        if (score > -1 && score < 7)
                            pickValue = false;
                    }

                    if (score > 0) {
                        symptoms.add(new Symptom(symptom, score));
                    }
                }else {
                    System.out.println(symptom + "\n\t\t\t\t1: yes" +
                            "\n\t\t\t\t2: no");
                    new Scanner(System.in).nextInt();
                }

                s_count++;

            }

            myHistory.add(new History(symptoms));
            store();


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }


    }

    private  Integer displayMenu(){

        int choice=0;
        while (choice<1 || choice>4) {
            System.out.println("Please select one of the options \n\n" +
                    "\t\t 1. Enter Symptoms\n" +
                    "\t\t 2. Display Symptoms Summary\n" +
                    "\t\t 3. I am I at Risk?\n" +
                    "\t\t 4. Exit");

            choice=new Scanner(System.in).nextInt();
            System.out.println();
        }

        return choice;
    }

    private void openSelectedMenu(int choice){
        if (choice == 1) {
            getSymptopms();
            openSelectedMenu(displayMenu());
        }

        else if (choice == 2) {
            displaySummary();
            openSelectedMenu(displayMenu());
        }
        else if (choice == 3) {
            riskIndicator();
        }
        else
            System.exit(1);


    }

    private void store(){
        File file=new File("history.txt");

        try {
            FileOutputStream fileOut = new FileOutputStream(file,false);
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOut);


            objectOutputStream.writeObject(myHistory);


            objectOutputStream.close();
            fileOut.close();



        } catch (IOException e ) {
            e.printStackTrace();
        }


    }


    private void loadHistory() throws IOException, ClassNotFoundException {
        File file=new File("history.txt");

        ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream(file));
         myHistory=(ArrayList<History>) inputStream.readObject();

//        for (Object history:myHistory){
//            History history1= (History) history;
//
//            for (Symptom symptom:history1.getPlayerSyptoms()) {
//                System.out.println(symptom.getName()+" "+symptom.getScore());
//            }
//
//        }
    }


    private void displaySummary(){

        for (int i = 0; i < myHistory.size(); i++) {
            History history=myHistory.get(i);
            int severity=0;
            int diffrence=0;

            for (Symptom symptom:history.getPlayerSyptoms()) {
                severity+=symptom.getScore();
            }


            if (i>0){
                int previous =myHistory.get(i-1).getPlayerSyptoms().size();
                int current  =history.getPlayerSyptoms().size();
                diffrence=Math.abs(previous-current);
            }

            String overalRating= diffrence < 3 && severity < 10 ?"No difference": diffrence < 3 ?"Unsure":
                    severity >= 15 ?"Very different":"";

            String summary=String.format("\n\t\t\t*********** Game   "+(i+1)+"  summary ***********" +
                               "\n\n\t\t\t\t Total Symptoms: %15s"+
                               "\n\t\t\t\t Symptom severity score: %7s" +
                               "\n\t\t\t\t Overall rating: %19s\n",history.getPlayerSyptoms().size(),severity,overalRating);

            System.out.println(summary);


        }
    }


    private void riskIndicator(){
        System.out.println();

        int size=myHistory.size();

        if (size>0)
        for (int i = size-1; i >size-2 ; i--) {


            History history=myHistory.get(i);
            int severity=0;
            int diffrence=0;

            for (Symptom symptom:history.getPlayerSyptoms()) {
                severity+=symptom.getScore();
            }


            if (i>0){
                int previous =myHistory.get(i-1).getPlayerSyptoms().size();
                int current  =history.getPlayerSyptoms().size();
                diffrence=Math.abs(previous-current);
            }

            String overalRating= diffrence < 3 && severity < 10 ?"No difference": diffrence < 3 ?"Unsure":
                    severity >= 15 ?"Very different":"";

            String image=overalRating.equals("No difference") ? "noDifference.jpeg":
                         overalRating.equals("Unsure")?"unsure.jpeg":"atRisk.jpeg";
            imageView.setImage(new Image(image));

        }

        mainStage.show();
    }
}
