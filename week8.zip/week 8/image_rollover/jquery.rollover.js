(function($){
    $.fn.changeImage = function() {
        return this.each(function() {

        });
    };
})(jQuery);
