package hotel;

public class Cell {
    private int roomNumber;
    private boolean occupancy;
    private boolean cleanedStatus;
    private int capacity;
    private double accountBalance;

    Cell(int roomNumber, boolean occupancy, boolean cleanedStatus, int capacity, double accountBalance) {
        this.roomNumber = roomNumber;
        this.occupancy = occupancy;
        this.cleanedStatus = cleanedStatus;
        this.capacity = capacity;
        this.accountBalance = accountBalance;
    }

    int getRoomNumber() {
        return roomNumber;
    }

    boolean isOccupancy() {
        return occupancy;
    }

    void setOccupancy(boolean occupancy) {
        this.occupancy = occupancy;
    }

    boolean isCleanedStatus() {
        return cleanedStatus;
    }

    void setCleanedStatus(boolean cleanedStatus) {
        this.cleanedStatus = cleanedStatus;
    }

    int getCapacity() {
        return capacity;
    }

    double getAccountBalance() {
        return accountBalance;
    }

    void setAccountBalance(double accountBalance) {
        this.accountBalance = accountBalance;
    }

    @Override
    public String toString() {
        return "" +
                "  roomNumber: " + roomNumber +
                ", occupancy: " + occupancy +
                ", cleanedStatus: " + cleanedStatus +
                ", capacity: " + capacity +
                ", accountBalance: " + accountBalance;
    }
}
