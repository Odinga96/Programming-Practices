package product;

/**
 * This is class declaration of a product
 */
public abstract class Product implements Comparable{


    private double price;
    private int code;

    /**
     * @param price price of the product
     * @param code the unique number to identify the product
     */
    public Product(double price, int code) {
        this.price = price;
        this.code = code;
    }

    /**
     * @return returns the price of a product
     */
    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }


    /**
     * @param o the object to compare with our object
     * @return returns a negative 0 or positive number
     */
    @Override
    public int compareTo(Object o) { return ((Product)o).getCode()- this.getCode(); }

    /**
     * @return prints out the object
     */
    @Override
    public String toString() { return code+ ":\t{Type:"+this.getClass().getSimpleName()+"\tprice= "+price+"\t"; }
}
