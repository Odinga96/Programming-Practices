
public class DS_My implements DataStructureADT {

    // TODO may wish to define an inner class
    class DS<T>{
        private T key;
        private T value;

        public DS(T key, T value) {
            this.key = key;
            this.value = value;
        }

        public T getKey() {
            return key;
        }

        public T getValue() {
            return value;
        }
    }
    // for storing key and value as a pair
    // such a class and its members should be "private"

    // Private Fields of the class
    // TODO create field(s) here to store data pairs
    private DS[] ds;
    private int  current=0;
    
    public DS_My() {
        // TODO Auto-generated method stub
        ds=new DS[10];
        for (int i = 0; i < ds.length; i++) { ds[i]=null; }

    }

    @Override
    public void insert(Comparable k, Object v) {
        // TODO Auto-generated method stub


        if (contains(k)) {
            if (current == ds.length - 1) {
                DS[] temp = ds;
                ds = new DS[(current + 1) * 2];

                System.arraycopy(temp, 0, ds, 0, temp.length);
                for (int i = current+1; i < ds.length; i++) { ds[i]=null; }

                ds[current++] =new DS(k,v);
            }else{ ds[current++] =new DS(k,v); }
        }else{
            try {
                throw new Exception("Duplicate keys found");
            } catch (Exception e) { e.printStackTrace(); }
        }
        
    }

    @Override
    public boolean remove(Comparable k) {
        // TODO Auto-generated method stub
        int swap_begin=0;
        boolean removed=false;
        if (contains(k)){
            for (int i = 0; i < ds.length; i++) {
                if (ds[i] != null)
                if (ds[i].key.equals(k)) {
                    ds[i] = null;
                    swap_begin=i;
                }
            }

            //swap null values
            while (ds[swap_begin+1] != null){
                DS temp=ds[swap_begin+1];
                ds[swap_begin]=temp;
                ds[swap_begin++]=null;
            }
            current--;
            removed=true;
        }else{
            try {
                throw new Exception("The key given is not valid");
            } catch (Exception ignored) { }
        }

        return removed;
    }

    @Override
    public boolean contains(Comparable k) {
        // TODO Auto-generated method stub

        boolean contained=false;
        for (DS d : ds) {
            if (d !=null)
            if (d.key.equals(k)) {
                contained=true;
                break;
            }
        }
        return contained;
    }

    @Override
    public Object get(Comparable k) {
        // TODO Auto-generated method stub
        int index = 0;
        if (contains(k)) {
            for (DS d : ds) {
                if (d.key.equals(k)) break;
                index++;
            }
        }else{
            try {
                throw new Exception("The key given is not valid");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return ds[index].value;
    }

    @Override
    public int size() { return current; }

}
