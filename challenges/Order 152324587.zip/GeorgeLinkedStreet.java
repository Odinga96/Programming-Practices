import java.util.Iterator;
/**
 * A Doubly-Linked Node implementation of the StreetParking Interface
 *
 * Implement the appropriate methods from StreetParking to get this to compile (and then delete this comment)
 */
public class GeorgeLinkedStreet implements StreetParking{

    public GeorgeLinkedStreet(int lengthOfStreet, int lengthOfGeorgesCar ) {

    }

}
