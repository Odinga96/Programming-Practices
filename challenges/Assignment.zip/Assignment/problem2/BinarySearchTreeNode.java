public class BinarySearchTreeNode {
    public int key;
    public BinarySearchTreeNode left;
    public BinarySearchTreeNode right;


}

