package acctMgr.model;

public interface Model {
	 void notifyChanged(ModelEvent me);
}
