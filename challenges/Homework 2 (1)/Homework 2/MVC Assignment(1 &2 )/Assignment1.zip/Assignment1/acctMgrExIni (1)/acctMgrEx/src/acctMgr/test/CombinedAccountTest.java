package acctMgr.test;

import org.junit.Before;
import org.junit.Test;

public class CombinedAccountTest {
    @Test
    void test1(){}
}
