package main;

import acctMgr.controller.AccountSelectionController;

public class Main {
    public static void main(String[] args) {
        new AccountSelectionController(args[0]);
    }
}
