package acctMgr.model;

public interface Model {
	public void notifyChanged(ModelEvent me);
}
