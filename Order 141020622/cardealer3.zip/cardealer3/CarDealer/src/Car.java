
public abstract class Car extends Object 
{
	String model; 			// manufacturer's name for the vehicle
	int color;				// color id
	double MilesPerGallon;	// miles per gallon
	
	Car()
	{
		model = "Unspecified";
		color = 0;
		MilesPerGallon = 0;
	}
	
	public Car(String model, int color, double milesPerGallon) {
		this.model = model;
		this.color = color;
		MilesPerGallon = milesPerGallon;
	}



	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public int getColor() {
		return color;
	}
	public void setColor(int color) {
		this.color = color;
	}
	public double getMPG() {
		return MilesPerGallon;
	}
	public void setMPG(double mPG) {
		MilesPerGallon = mPG;
	}

	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Car other = (Car) obj;
		if (Double.doubleToLongBits(MilesPerGallon) != Double.doubleToLongBits(other.MilesPerGallon))
			return false;
		if (color != other.color)
			return false;
		if (model == null) {
			if (other.model != null)
				return false;
		} else if (!model.equals(other.model))
			return false;
		return true;
	}

	public String toString() {
		return "Car [model=" + model + ", "
				+ "color=" + color + ","
				+ " MilesPerGallon=" + MilesPerGallon + "]";
	}
}
