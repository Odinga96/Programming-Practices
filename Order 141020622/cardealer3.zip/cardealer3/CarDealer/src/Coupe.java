
public class Coupe extends Car
{
	private int numPassengers;
	
	Coupe()
	{
		super();
		numPassengers = 1;
	}
	

	public Coupe(String model, int color, double milesPerGallon, int pass) 
	{
		super(model, color, milesPerGallon);
		numPassengers = pass;
	}



	public int getNumPassengers() 
	{
		return numPassengers;
	}

	public void setNumPassengers(int numPassengers) 
	{
		this.numPassengers = numPassengers;
	}

	public String toString() {
		 return super.toString() +
			", Coupe [numPassengers=" + numPassengers + "]";
	}
	
	
	
}
