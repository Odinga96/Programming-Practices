
public class Truck extends Car
{
	double payload;
	
	Truck()
	{
		super();
		payload = 0;
	}

	public Truck(String model, int color, double milesPerGallon, double pl) 
	{
		super(model, color, milesPerGallon);
		payload = pl;
	}



	public double getPayload() 
	{
		return payload;
	}

	public void setPayload(double payload) 
	{
		this.payload = payload;
	}
	
	public String toString() 
	{
		return super.toString() +
				", Truck [payload=" + payload + "]";
	}
	

}
