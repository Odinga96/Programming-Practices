
public class Van extends Car
{

    public Van() {
    }

    public Van(String model, int color, double milesPerGallon) {
        super(model, color, milesPerGallon);
    }

    public String toString()
    {
        return super.toString() + ",VAN";
    }
}
