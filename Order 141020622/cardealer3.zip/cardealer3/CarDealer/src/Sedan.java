public class Sedan extends SUVS {

    public Sedan() {
    }

    public Sedan(String model, int color, double milesPerGallon) {
        super(model, color, milesPerGallon);
    }

    public String toString()
    {
        return super.toString() + ",Sedan";
    }
}
