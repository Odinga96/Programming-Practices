public class SUVS extends Car {


    public SUVS() {
    }

    public SUVS(String model, int color, double milesPerGallon) {
        super(model, color, milesPerGallon);
    }

    public String toString()
    {
        return super.toString() + ",SUV";
    }

}