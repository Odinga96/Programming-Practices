
public class Driver 
{
	public static void main(String[] args) 
	{
		Dealership dealer = new Dealership(1000);
		while (true)
		dealer.DealWithIt();
	}
}
