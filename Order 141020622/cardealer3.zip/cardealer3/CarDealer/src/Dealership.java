import javax.swing.JOptionPane;
import java.util.Random;
import java.util.Scanner;

public class Dealership 
{
	private Car[] inventory;
	int count=0;

	public Dealership(int capacity) 
	{
		this.inventory = new Car[capacity];
	
		for (int i = 0; i < inventory.length; ++i)
			inventory[i] = null;
	}

	public Car[] getInventory() 
	{
		return inventory;
	}

	public void setInventory(Car[] inventory) 
	{
		this.inventory = inventory;
	}

	public String toString()
	{
		count=0;
		String ans = 
				" size=" + inventory.length
				+ "\n";
		
		for (int i = 0; i < inventory.length; ++i) {
			if (inventory[i] != null) {
				ans = ans + i + ":" + inventory[i].toString() + "\n";
				count++;
			}
		}
		
		ans = ans + " =========== Total count: "+count+"============\n" +
				"-------------------<end>------------------------ \n";
		
		return ans;
	}
	
	public int Add(Car vehicle)
	{
		for (int i = 0; i < inventory.length; ++i)	
			if (inventory[i] == null)
			{
				inventory[i] = vehicle;
				return i;
			}
		return -1;
	}
	
	public void DealWithIt()
	{
	// Offer choice
		String strMenu = 
			"Choose function to perform\n" +
			"01. Show all the cars\n" +
					"02. Show trucks with payload>= 1 \n"+
					"03. Show all Sedans\n" +
					"04. Show all the luxury\n" +
					"05. Show all the economy\n" +
					"06. Show all the economy with over 40mpg\n" +
					"07. Add a car\n" +
					"08. Delete a car\n" +
			"09. Add 20 cars\n" +
			"10. Exit\n";
		
		// Obtain choice		
		String strChoice = JOptionPane.
			showInputDialog(strMenu);
		int intChoice = Integer.parseInt(strChoice);
		
		// Act upon choice
		switch (intChoice)
		{
			case(1):
			{
				System.out.println(toString());

				break;
			}
			case(2):
			{
				for (Car car:inventory) {

					if ((car instanceof Truck) && ((Truck) car).payload>=1000)
						System.out.println(car.toString());
				}
				break;
			}
			case(3):
			{
				System.out.println("========== All the available Sedans=======");
				for (Car car:inventory) {
					if (car instanceof Sedan)
						System.out.println(car.toString());
				}
				System.out.println();
				break;
			}			
			case(4):
			{
				System.out.println("========== All the available Luxury=======");
				for (Car car:inventory) {
					if (car instanceof Luxury)
						System.out.println(car.toString());
				}
				System.out.println("\n");
				break;
			}
			case 5:
			{
				System.out.println("========== All the available Economy=======");

				for (Car car:inventory) {
					if (car instanceof Economy)
						System.out.println(car.toString());
				}

				System.out.println("\n");
				break;
			}
			case 6:
			{
				System.out.println("========== All the available Econoy with mpg>40 =======");

				for (Car car:inventory) {
					if ((car instanceof Economy) && car.MilesPerGallon>40)
						System.out.println(car.toString());
				}
				System.out.println("\n");
				break;
			}
			case 7:
			{
				Scanner scanner=new Scanner(System.in);
				System.out.println("Select car to add\n" +
						"1. Truck\n" +
						"2. Sedan\n" +
						"3. Luxury\n" +
						"4. Economy\n" +
						"5. Van\n" +
						"6. SUV\n" +
						"7. Coupe\n");

				int add=scanner.nextInt();

				System.out.println("Enter model name:  ");
				String model=scanner.next();

				System.out.println("Enter the color id(integer): ");
				int id=scanner.nextInt();

				System.out.println("Enter miles per gallon for the car: ");
				double mpg=scanner.nextDouble();

				switch (add){
					case 1:
						System.out.println("enter payload");
						double payload=scanner.nextDouble();

						Add(new Truck(model,id,mpg,payload));
						break;
					case 2:
						Add(new Sedan(model,id,mpg));
						break;
					case 3:
						System.out.println("enter number of passengers");
						int passengers=scanner.nextInt();
						Add(new Luxury(model,id,mpg,passengers));
						break;
					case 4:
						System.out.println("enter number of passengers");
						int passenger=scanner.nextInt();
						Add(new Economy(model,id,mpg,passenger));
						break;
					case 5:
						Add(new Van(model,id,mpg));
						break;
					case 6:
						Add(new SUVS(model,id,mpg));
						break;
					case 7:

						System.out.println("enter number of passengers");
						int passengerc=scanner.nextInt();
						Add(new Coupe(model,id,mpg,passengerc));

						break;
						default:
							System.out.println("please choose the right option");
							break;
				}

				break;
			}
			case 8:
			{

				System.out.println("Choose the car to remove");
				for (int i = 0; i <inventory.length; i++) {
					 if (inventory[i] !=null){
						 System.out.println(i+":\t\t\t"+inventory[i].toString());
					 }
				}

				System.out.println("\n\n Enter ");
                 int index=new Scanner(System.in).nextInt();
				inventory[index]=null;
				System.out.println("\n\t Cars left in the  Dealership\n\n"+toString());
				break;
			}
			case(9):
			{
				for (int i = 0; i < 20; ++i)
				{
					int random= new Random().nextInt(5)+1;
					if (random==0) {
						String[] models={"ISUZU D MX","Isuzu Giga","Isuzu Aska","GM","MERCEDES"};

						int pick=new Random().nextInt(5);

						Car c = new Truck(models[pick], pick*pick, pick*(new Random().nextInt(20)), new Random().nextInt(20000));
						Add(c);
					}else  if(random==1){

						String[] models={"Honda Odyssey","Chrysler Pacifica","V8","GM","MERCEDES"};

						int pick=new Random().nextInt(5);

						Car c=new Sedan(models[pick], new Random().nextInt(100),new Random().nextInt(100));
						Add(c);
					}
					else  if(random==2){
						String[] models={"Ford EcoSport","Jeep Grand Cheron","Jeep Wrangler","Chevrolet Tahoe","Toyota 4Runner"};

						int pick=new Random().nextInt(5);

						Car c=new SUVS(models[pick], new Random().nextInt(100),new Random().nextInt(100));
						Add(c);
					}
					else  if(random==3){

						String[] models={"Toyota Siena","Dodge Grand Caravan","Kia Sedon","Ford Tansit 250","MERCEDES Transit"};

						int pick=new Random().nextInt(5);

						Car c=new Van(models[pick],new Random().nextInt(100),new Random().nextInt(100));
						Add(c);
					}
					else  if(random==4){
						String[] models={"Lexus RX 350","Audi TT","BMW 5 Series","Lexus CT","2017 Porsche Macan"};

						int pick=new Random().nextInt(5);

						Car c=new Luxury(models[pick], new Random().nextInt(100),new Random().nextInt(100),new Random().nextInt(5)+1);
						Add(c);
					}
					else  if(random==5){
						String[] models={"ISUZU D MX","Isuzu Giga","Isuzu Aska","GM","MERCEDES"};

						int pick=new Random().nextInt(5);

						Car c=new Economy(models[pick], pick*pick,pick*(new Random().nextInt(20)),random+7);
						Add(c);
					}

				}

				System.out.println(toString());
				break;
			}
			case (10):
			{
				System.exit(1);
				break;
			}
			default:
			{
				System.out.println(toString());
				break;
			}
			
		} // end select

	}
}
