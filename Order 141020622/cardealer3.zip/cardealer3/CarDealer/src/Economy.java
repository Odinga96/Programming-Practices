public class Economy extends Coupe{

    public Economy() {
    }

    public Economy(String model, int color, double milesPerGallon, int pass) {
        super(model, color, milesPerGallon, pass);
    }

    public String toString()
    {
        return super.toString() + "[type=Economy]";
    }
}
