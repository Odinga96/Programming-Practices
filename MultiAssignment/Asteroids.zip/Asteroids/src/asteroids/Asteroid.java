package asteroids;

import java.awt.Shape;
import java.awt.geom.*;
import static asteroids.Constants.*;

/**
 * Represents asteroids
 *
 */
class Asteroid extends Polygon {
	
	// The size of the asteroid (0 = small, 1 = medium, 2 = large)
	private int size;
	
	// The outline of the asteroid
	private Shape outline;
	
	
	/**
	 * Create an asteroid of the specified variety and size and
	 * position it at the provided coordinates.
	 */
	public Asteroid (int variety, int size, double x, double y) {
		this.size = size;
		setPosition(x, y);
		outline = createAsteroid(variety, size);
	}
	

	protected Shape getOutline () {
		return outline;
	}
	
	/**
	 * Creates the outline of the asteroid based on its variety and size.
	 */
	private Shape createAsteroid (int variety, int size) {
		
		// This will contain the outline
		Path2D.Double poly = new Path2D.Double();
		
		// Fill out according to variety
		if (variety == 0) {
			poly.moveTo(0, -30);
			poly.lineTo(28, -15);
			poly.lineTo(20, 20);
			poly.lineTo(4, 8);
			poly.lineTo(-1, 30);
			poly.lineTo(-12, 15);
			poly.lineTo(-5, 2);
			poly.lineTo(-25, 7);
			poly.lineTo(-10, -25);
			poly.closePath();
		}
		else if (variety == 1) {
			poly.moveTo(10, -28);
			poly.lineTo(7, -16);
			poly.lineTo(30, -9);
			poly.lineTo(30, 9);
			poly.lineTo(10, 13);
			poly.lineTo(5, 30);
			poly.lineTo(-8, 28);
			poly.lineTo(-6, 6);
			poly.lineTo(-27, 12);
			poly.lineTo(-30, -11);
			poly.lineTo(-6, -15);
			poly.lineTo(-6, -28);
			poly.closePath();
		}
		else if (variety == 2) {
			poly.moveTo(10, -30);
			poly.lineTo(30, 0);
			poly.lineTo(15, 30);
			poly.lineTo(0, 15);
			poly.lineTo(-15, 30);
			poly.lineTo(-30, 0);
			poly.lineTo(-10, -30);
			poly.closePath();
		}
		else {
			poly.moveTo(30, -18);
			poly.lineTo(5, 5);
			poly.lineTo(30, 15);
			poly.lineTo(15, 30);
			poly.lineTo(0, 25);
			poly.lineTo(-15, 30);
			poly.lineTo(-25, 8);
			poly.lineTo(-10, -25);
			poly.lineTo(0, -30);
			poly.lineTo(10, -30);
			poly.closePath();
		}
		
		// Scale to the desired size
		double scale = ASTEROID_SCALE[size];
		poly.transform(AffineTransform.getScaleInstance(scale, scale));
		
		// Return the outline
		return poly;
	}
	
	
	/**
	 * Returns the size of the asteroid
	 */
	@Override
	public int getSize () {
		return size;
	}

	
}