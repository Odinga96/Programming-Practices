$(document).ready(function() {


      // Selects an element which is a parent of an image
       // element and calls the change image function to this method
     $("#image_rollovers li").changeImage();
}); // end ready
