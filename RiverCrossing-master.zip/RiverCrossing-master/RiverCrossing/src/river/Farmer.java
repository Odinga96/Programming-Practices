package river;

import river.GameEngine.Location;

public class Farmer extends GameObject {

    public Farmer() {
        name = "Farmer";
        location = Location.START;
    }

}
