package river;

import river.GameEngine.Location;

public class Beans extends GameObject {

    public Beans() {
        name = "Beans";
        location = Location.START;
    }
}
