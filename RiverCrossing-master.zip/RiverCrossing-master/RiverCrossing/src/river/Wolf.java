package river;

import river.GameEngine.Location;

public class Wolf extends GameObject {

    public Wolf() {
        name = "Wolf";
        location = Location.START;
    }

}
